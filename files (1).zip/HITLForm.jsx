import React, { useState } from 'react';
import './HITLForm.css';

/**
 * HITLForm
 *
 * Props:
 *   missingEntities  string[]   Entity names returned in missing_entities[] by the backend.
 *   onSubmit         fn         Called with { [entityName]: value } when the user submits.
 *   resolved         boolean    True once submitted — locks the form.
 */
export default function HITLForm({ missingEntities = [], onSubmit, resolved }) {
  const initial = Object.fromEntries(missingEntities.map(e => [e, '']));
  const [values,     setValues]     = useState(initial);
  const [touched,    setTouched]    = useState({});
  const [submitting, setSubmitting] = useState(false);

  const update = (name, value) => {
    setValues(v  => ({ ...v, [name]: value }));
    setTouched(t => ({ ...t, [name]: true }));
  };

  // All entities must have a non-empty value
  const isValid = missingEntities.every(e => values[e]?.toString().trim());

  const handleSubmit = async () => {
    if (!isValid || submitting || resolved) return;
    // Mark all as touched so errors show on attempted submit
    setTouched(Object.fromEntries(missingEntities.map(e => [e, true])));
    if (!isValid) return;
    setSubmitting(true);
    await onSubmit(values);
  };

  // Human-friendly label: "customer_name" → "Customer Name"
  const toLabel = (entity) =>
    entity
      .replace(/_/g, ' ')
      .replace(/\b\w/g, c => c.toUpperCase());

  return (
    <div className="hitl-card">

      {/* ── Header ── */}
      <div className="hitl-header">
        <span className="hitl-icon">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
            <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="1.5"/>
            <path d="M12 8v4M12 16h.01" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
          </svg>
        </span>
        <div>
          <p className="hitl-title">Additional Information Needed</p>
          <p className="hitl-subtitle">
            Please provide the {missingEntities.length === 1 ? 'value' : 'values'} below to continue
          </p>
        </div>
        {resolved && (
          <span className="hitl-resolved-badge">
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none">
              <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            Submitted
          </span>
        )}
      </div>

      {/* ── Divider ── */}
      <div className="hitl-divider" />

      {/* ── Entity fields ── */}
      <div className="hitl-fields">
        {missingEntities.map((entity, idx) => {
          const value    = values[entity] ?? '';
          const hasError = touched[entity] && !value.trim();

          return (
            <div key={entity} className={`hitl-field ${hasError ? 'field-error' : ''}`}>
              <label className="hitl-label">
                {toLabel(entity)}
                <span className="required-star">*</span>
              </label>

              <div className="hitl-input-wrapper">
                <span className="hitl-entity-tag">{entity}</span>
                <input
                  className="hitl-input"
                  type="text"
                  value={value}
                  placeholder={`Enter ${toLabel(entity).toLowerCase()}…`}
                  disabled={resolved}
                  autoFocus={idx === 0}
                  onChange={e => update(entity, e.target.value)}
                  onBlur={() => setTouched(t => ({ ...t, [entity]: true }))}
                  onKeyDown={e => {
                    if (e.key === 'Enter' && missingEntities.length === 1) handleSubmit();
                  }}
                />
              </div>

              {hasError && (
                <span className="field-hint">This field is required</span>
              )}
            </div>
          );
        })}
      </div>

      {/* ── Submit ── */}
      {!resolved && (
        <button
          className="hitl-submit"
          disabled={!isValid || submitting}
          onClick={handleSubmit}
        >
          {submitting ? (
            <>
              <span className="submit-spinner" />
              Resuming workflow…
            </>
          ) : (
            <>
              Continue
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none">
                <path d="M5 12h14M12 5l7 7-7 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </>
          )}
        </button>
      )}
    </div>
  );
}
