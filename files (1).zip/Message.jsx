import React from 'react';
import './Message.css';
import HITLForm from './HITLForm.jsx';

/* ── Typing indicator ────────────────── */
function TypingDots() {
  return (
    <span className="typing-dots" aria-label="Thinking">
      <span /><span /><span />
    </span>
  );
}

/* ── Avatar ──────────────────────────── */
function Avatar({ role }) {
  if (role === 'user') {
    return (
      <div className="avatar avatar-user">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor">
          <path d="M12 12c2.7 0 4.8-2.1 4.8-4.8S14.7 2.4 12 2.4 7.2 4.5 7.2 7.2 9.3 12 12 12zm0 2.4c-3.2 0-9.6 1.6-9.6 4.8v2.4h19.2v-2.4c0-3.2-6.4-4.8-9.6-4.8z"/>
        </svg>
      </div>
    );
  }
  return (
    <div className="avatar avatar-ai">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
        <path d="M12 2L2 7l10 5 10-5-10-5z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round"/>
        <path d="M2 17l10 5 10-5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M2 12l10 5 10-5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    </div>
  );
}

/* ── Main component ──────────────────── */
export default function Message({ message, onHITLSubmit }) {
  const { role, content, status, fields, resolved } = message;

  if (role === 'system') {
    return (
      <div className="message-system">
        <span className="system-check">
          <svg width="11" height="11" viewBox="0 0 24 24" fill="none">
            <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </span>
        {content}
      </div>
    );
  }

  if (role === 'hitl') {
    return (
      <div className={`message-hitl-wrapper ${resolved ? 'resolved' : ''}`}>
        <HITLForm
          missingEntities={message.missingEntities}
          onSubmit={onHITLSubmit}
          resolved={resolved}
        />
      </div>
    );
  }

  const isUser = role === 'user';
  const isPending = status === 'pending';
  const isError = status === 'error';

  return (
    <div className={`message-row ${isUser ? 'row-user' : 'row-ai'}`}>
      {!isUser && <Avatar role="ai" />}

      <div className={`bubble ${isUser ? 'bubble-user' : 'bubble-ai'} ${isError ? 'bubble-error' : ''}`}>
        {isPending ? (
          <TypingDots />
        ) : (
          <div className="bubble-content">
            {content.split('\n').map((line, i) =>
              line === '' ? <br key={i} /> : <p key={i}>{line}</p>
            )}
          </div>
        )}
      </div>

      {isUser && <Avatar role="user" />}
    </div>
  );
}
