import { useState, useCallback, useRef } from 'react';
import { sendQuery, resumeGraph } from '../utils/api.js';

/**
 * Message shapes
 * ──────────────────────────────────────────────────────────────────
 * User / Assistant / System:
 *   { id, role: 'user'|'assistant'|'system', content: string, status: 'pending'|'done'|'error' }
 *
 * HITL:
 *   { id, role: 'hitl', missingEntities: string[], resolved: boolean, status: 'done' }
 *
 * ── Backend response shapes ───────────────────────────────────────
 * /query  HITL:    { status: "Awaiting USER_INPUT", missing_entities: string[], thread_id }
 * /query  success: { status: "COMPLETE",            answer: string,             thread_id }
 * /resume success: { status: "COMPLETE",            answer: string,             final_query }
 */

let _id = 0;
const uid = () => `msg-${Date.now()}-${_id++}`;

const STATUS_HITL     = 'Awaiting USER_INPUT';
const STATUS_COMPLETE = 'COMPLETE';

export function useChat() {
  const [messages,  setMessages]  = useState([]);
  const [threadId,  setThreadId]  = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error,     setError]     = useState(null);

  // Ref to the id of the currently open (unresolved) HITL card
  const hitlMsgIdRef = useRef(null);

  // ── helpers ──────────────────────────────────────────────────────
  const addMessage = useCallback((msg) => {
    setMessages(prev => [...prev, { id: uid(), ...msg }]);
  }, []);

  const resolvePending = useCallback((pendingId, patch) => {
    setMessages(prev =>
      prev.map(m => m.id === pendingId ? { ...m, ...patch } : m)
    );
  }, []);

  const resolveHITL = useCallback((id) => {
    setMessages(prev =>
      prev.map(m => m.id === id ? { ...m, resolved: true } : m)
    );
  }, []);

  // ── parse & apply a backend response ─────────────────────────────
  /**
   * @param {Object} response   Raw JSON from /query or /resume
   * @param {string} pendingId  ID of the "pending" assistant bubble to replace
   */
  const handleResponse = useCallback((response, pendingId) => {
    if (response.status === STATUS_COMPLETE) {
      // Replace the typing placeholder with the real answer
      resolvePending(pendingId, {
        content: response.answer,
        status:  'done',
      });
      hitlMsgIdRef.current = null;

    } else if (response.status === STATUS_HITL) {
      // Remove the typing placeholder — no AI text to show
      setMessages(prev => prev.filter(m => m.id !== pendingId));

      // Insert a HITL card carrying the list of missing entity names
      const hitlId = uid();
      hitlMsgIdRef.current = hitlId;
      setMessages(prev => [
        ...prev,
        {
          id:              hitlId,
          role:            'hitl',
          missingEntities: response.missing_entities ?? [],
          resolved:        false,
          status:          'done',
        },
      ]);

    } else {
      // Unexpected status — surface it as an error bubble
      resolvePending(pendingId, {
        content: `Unexpected response status: "${response.status}"`,
        status:  'error',
      });
    }
  }, [resolvePending]);

  // ── start new chat ────────────────────────────────────────────────
  // No backend call needed — backend uses thread_id=null as a fresh session signal
  const startNewChat = useCallback(() => {
    setMessages([]);
    setThreadId(null);
    setError(null);
    hitlMsgIdRef.current = null;
  }, []);

  // ── send user message ─────────────────────────────────────────────
  const send = useCallback(async (text) => {
    if (!text.trim() || isLoading) return;

    setError(null);
    setIsLoading(true);

    // Add the user bubble immediately
    addMessage({ role: 'user', content: text, status: 'done' });

    // Add typing indicator (pending assistant bubble)
    const pendingId = uid();
    setMessages(prev => [
      ...prev,
      { id: pendingId, role: 'assistant', content: '', status: 'pending' },
    ]);

    try {
      // thread_id is null on the very first message; backend returns one in the response
      const response = await sendQuery(threadId, text);

      // Persist the thread_id the backend gave us (present on both HITL and COMPLETE)
      if (response.thread_id) setThreadId(response.thread_id);

      handleResponse(response, pendingId);
    } catch (err) {
      resolvePending(pendingId, {
        content: 'Something went wrong. Please try again.',
        status:  'error',
      });
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  }, [threadId, isLoading, addMessage, resolvePending, handleResponse]);

  // ── submit HITL entity values ─────────────────────────────────────
  /**
   * @param {Object} entityValues  { [entityName]: userValue }
   *   Keys are the strings from missing_entities[], values are what the user typed.
   */
  const submitHITL = useCallback(async (entityValues) => {
    if (!threadId || isLoading) return;

    const currentHitlId = hitlMsgIdRef.current;

    setError(null);
    setIsLoading(true);

    // Lock the HITL card so it can't be submitted twice
    if (currentHitlId) resolveHITL(currentHitlId);

    // Show a compact confirmation line in the thread
    const summary = Object.entries(entityValues)
      .map(([k, v]) => `${k}: ${v}`)
      .join(' · ');
    addMessage({ role: 'system', content: `Provided: ${summary}`, status: 'done' });

    // Add typing indicator again while graph resumes
    const pendingId = uid();
    setMessages(prev => [
      ...prev,
      { id: pendingId, role: 'assistant', content: '', status: 'pending' },
    ]);

    try {
      // /resume always returns COMPLETE (per the spec)
      const response = await resumeGraph(threadId, entityValues);
      handleResponse(response, pendingId);
    } catch (err) {
      resolvePending(pendingId, {
        content: 'Failed to resume. Please try again.',
        status:  'error',
      });
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  }, [threadId, isLoading, resolveHITL, addMessage, resolvePending, handleResponse]);

  return {
    messages,
    threadId,
    isLoading,
    error,
    send,
    submitHITL,
    startNewChat,
  };
}
