/**
 * mock-server.js
 *
 * Express mock of the real LangGraph backend.
 * Run with: node mock-server.js
 *
 * Routes:
 *   POST /query   → HITL or COMPLETE
 *   POST /resume  → COMPLETE
 *
 * Install: npm install express cors uuid
 */

import express from 'express';
import cors    from 'cors';
import { v4 as uuidv4 } from 'uuid';

const app  = express();
const PORT = 8000;

app.use(cors());
app.use(express.json());

// Per-thread turn counter
const threads = {};

/* ── POST /query ────────────────────────────────────── */
app.post('/query', (req, res) => {
  const { query, thread_id } = req.body;

  // Create thread if new
  const tid   = thread_id ?? uuidv4();
  const state = threads[tid] ?? { turn: 0 };
  state.turn++;
  threads[tid] = state;

  console.log(`[QUERY] thread=${tid} turn=${state.turn} query="${query}"`);

  // Simulate HITL on every 2nd turn
  if (state.turn % 2 === 0) {
    console.log(`  → HITL interrupt`);
    return res.json({
      status:           'Awaiting USER_INPUT',
      missing_entities: ['customer_name', 'order_id'],
      thread_id:        tid,
    });
  }

  console.log(`  → COMPLETE`);
  res.json({
    status:    'COMPLETE',
    answer:    `You asked: "${query}"\n\nThis is a mock LangGraph response (turn ${state.turn}). The next message will trigger a Human-In-The-Loop interrupt requesting missing entity values.`,
    thread_id: tid,
  });
});

/* ── POST /resume ───────────────────────────────────── */
app.post('/resume', (req, res) => {
  const { thread_id, ...entities } = req.body;

  console.log(`[RESUME] thread=${thread_id}`, entities);

  const merged = Object.entries(entities)
    .map(([k, v]) => `${k} = "${v}"`)
    .join(', ');

  res.json({
    status:      'COMPLETE',
    answer:      `Workflow resumed successfully.\n\nReceived your input — ${merged}.\n\nThe graph has continued from where it was interrupted and produced this final answer.`,
    final_query: `[merged query incorporating: ${merged}]`,
  });
});

app.listen(PORT, () => {
  console.log(`Mock backend → http://localhost:${PORT}`);
  console.log(`  POST /query   (thread_id + query)`);
  console.log(`  POST /resume  (thread_id + entity values flat)`);
});
