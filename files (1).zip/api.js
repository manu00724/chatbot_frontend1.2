/**
 * api.js – All communication with the LangGraph backend.
 *
 * ── Actual backend contract ──────────────────────────────────────
 *
 * POST /query
 *   Body:    { query: string, thread_id: string | null }
 *   HITL:    { status: "Awaiting USER_INPUT", missing_entities: string[], thread_id }
 *   Success: { status: "COMPLETE",            answer: string,             thread_id }
 *
 * POST /resume
 *   Body:    { thread_id: string, [entityName]: value, ... }
 *   Success: { status: "COMPLETE", answer: string, final_query: string }
 *
 * thread_id lifecycle:
 *   - On first message it is null; the backend returns one in every response.
 *   - "New Chat" resets thread_id to null on the frontend — no backend call needed.
 */

const BASE = '/api';

async function request(path, body) {
  const res = await fetch(`${BASE}${path}`, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify(body),
  });

  if (!res.ok) {
    const text = await res.text().catch(() => 'Unknown error');
    throw new Error(`HTTP ${res.status}: ${text}`);
  }

  return res.json();
}

/**
 * Send the user's query to the graph.
 * @param {string|null} thread_id  Null on the very first message of a session.
 * @param {string}      query      The user's message text.
 */
export async function sendQuery(thread_id, query) {
  return request('/query', { query, thread_id });
}

/**
 * Resume a paused graph after the user has filled in missing entities.
 * @param {string} thread_id   The thread to resume.
 * @param {Object} entities    { [entityName]: value } — the missing fields filled in.
 */
export async function resumeGraph(thread_id, entities) {
  // Spread entities flat alongside thread_id as the backend expects
  return request('/resume', { thread_id, ...entities });
}
