import React, { useState, useRef, useEffect } from 'react';
import './ChatInput.css';

export default function ChatInput({ onSend, isLoading, disabled }) {
  const [text, setText] = useState('');
  const textareaRef = useRef(null);

  // Auto-grow
  useEffect(() => {
    const ta = textareaRef.current;
    if (!ta) return;
    ta.style.height = 'auto';
    ta.style.height = Math.min(ta.scrollHeight, 180) + 'px';
  }, [text]);

  const canSend = text.trim().length > 0 && !isLoading && !disabled;

  const handleSend = () => {
    if (!canSend) return;
    onSend(text.trim());
    setText('');
  };

  const handleKey = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="input-bar-outer">
      <div className={`input-bar ${disabled ? 'input-disabled' : ''}`}>
        <textarea
          ref={textareaRef}
          className="chat-textarea"
          placeholder={disabled ? 'Complete the form above to continue…' : 'Ask anything… (Shift+Enter for new line)'}
          value={text}
          rows={1}
          disabled={isLoading || disabled}
          onChange={e => setText(e.target.value)}
          onKeyDown={handleKey}
        />

        <button
          className={`send-btn ${canSend ? 'send-active' : ''}`}
          onClick={handleSend}
          disabled={!canSend}
          aria-label="Send"
        >
          {isLoading ? (
            <span className="send-spinner" />
          ) : (
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
              <path d="M22 2L11 13" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M22 2L15 22l-4-9-9-4 20-7z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          )}
        </button>
      </div>

      <p className="input-caption">
        LangGraph powers this chat · Responses may be interrupted for human input
      </p>
    </div>
  );
}
