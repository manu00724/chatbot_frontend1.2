import React from 'react';
import './Header.css';

export default function Header({ threadId, onNewChat }) {
  return (
    <header className="header">
      <div className="header-left">
        <div className="logo">
          <span className="logo-icon">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
              <path d="M12 2L2 7l10 5 10-5-10-5z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/>
              <path d="M2 17l10 5 10-5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M2 12l10 5 10-5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </span>
          <span className="logo-text">LangGraph</span>
          <span className="logo-tag">Chat</span>
        </div>

        {threadId && (
          <div className="thread-badge">
            <span className="thread-dot" />
            <span className="thread-id">
              {threadId.length > 16 ? `…${threadId.slice(-12)}` : threadId}
            </span>
          </div>
        )}
      </div>

      <button className="new-chat-btn" onClick={onNewChat} title="Start a new conversation">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
          <path d="M12 5v14M5 12h14" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
        </svg>
        New Chat
      </button>
    </header>
  );
}
