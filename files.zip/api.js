/**
 * api.js – All communication with the LangGraph backend.
 *
 * Backend contract (assumed):
 *
 * POST /api/chat
 *   Body: { thread_id, message }
 *   Response (normal):   { type: "ai",   thread_id, content }
 *   Response (HITL):     { type: "hitl", thread_id, fields: [{ name, label, type, required, placeholder }] }
 *
 * POST /api/resume
 *   Body: { thread_id, fields: { [fieldName]: value, ... } }
 *   Response (normal):   { type: "ai",   thread_id, content }
 *   Response (HITL):     { type: "hitl", thread_id, fields: [...] }
 *
 * POST /api/thread/new
 *   Response: { thread_id }
 */

const BASE = '/api';

async function request(path, body) {
  const res = await fetch(`${BASE}${path}`, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify(body),
  });

  if (!res.ok) {
    const text = await res.text().catch(() => 'Unknown error');
    throw new Error(`HTTP ${res.status}: ${text}`);
  }

  return res.json();
}

export async function createThread() {
  const data = await request('/thread/new', {});
  return data.thread_id;
}

export async function sendMessage(thread_id, message) {
  return request('/chat', { thread_id, message });
}

export async function resumeGraph(thread_id, fields) {
  return request('/resume', { thread_id, fields });
}
