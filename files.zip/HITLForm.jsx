import React, { useState } from 'react';
import './HITLForm.css';

export default function HITLForm({ fields = [], onSubmit, resolved }) {
  const initial = Object.fromEntries(fields.map(f => [f.name, '']));
  const [values,  setValues]  = useState(initial);
  const [touched, setTouched] = useState({});
  const [submitting, setSubmitting] = useState(false);

  const update = (name, value) => {
    setValues(v => ({ ...v, [name]: value }));
    setTouched(t => ({ ...t, [name]: true }));
  };

  const isValid = fields.every(f => !f.required || values[f.name]?.toString().trim());

  const handleSubmit = async () => {
    if (!isValid || submitting || resolved) return;
    setSubmitting(true);
    await onSubmit(values);
  };

  const renderField = (field) => {
    const { name, label, type = 'text', placeholder, required } = field;
    const value = values[name] ?? '';
    const hasError = touched[name] && required && !value.trim();

    if (type === 'select') {
      return (
        <div key={name} className={`hitl-field ${hasError ? 'field-error' : ''}`}>
          <label className="hitl-label">
            {label ?? name}
            {required && <span className="required-star">*</span>}
          </label>
          <div className="select-wrapper">
            <select
              className="hitl-select"
              value={value}
              disabled={resolved}
              onChange={e => update(name, e.target.value)}
            >
              <option value="">Choose…</option>
              {(field.options ?? []).map(opt => (
                <option key={opt.value ?? opt} value={opt.value ?? opt}>
                  {opt.label ?? opt}
                </option>
              ))}
            </select>
            <span className="select-arrow">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none">
                <path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </span>
          </div>
          {hasError && <span className="field-hint">This field is required</span>}
        </div>
      );
    }

    if (type === 'textarea') {
      return (
        <div key={name} className={`hitl-field ${hasError ? 'field-error' : ''}`}>
          <label className="hitl-label">
            {label ?? name}
            {required && <span className="required-star">*</span>}
          </label>
          <textarea
            className="hitl-textarea"
            value={value}
            placeholder={placeholder ?? ''}
            disabled={resolved}
            rows={3}
            onChange={e => update(name, e.target.value)}
            onBlur={() => setTouched(t => ({ ...t, [name]: true }))}
          />
          {hasError && <span className="field-hint">This field is required</span>}
        </div>
      );
    }

    return (
      <div key={name} className={`hitl-field ${hasError ? 'field-error' : ''}`}>
        <label className="hitl-label">
          {label ?? name}
          {required && <span className="required-star">*</span>}
        </label>
        <input
          className="hitl-input"
          type={type}
          value={value}
          placeholder={placeholder ?? ''}
          disabled={resolved}
          onChange={e => update(name, e.target.value)}
          onBlur={() => setTouched(t => ({ ...t, [name]: true }))}
          onKeyDown={e => {
            if (e.key === 'Enter' && fields.length === 1) handleSubmit();
          }}
        />
        {hasError && <span className="field-hint">This field is required</span>}
      </div>
    );
  };

  return (
    <div className="hitl-card">
      {/* Header */}
      <div className="hitl-header">
        <span className="hitl-icon">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
            <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="1.5"/>
            <path d="M12 8v4M12 16h.01" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
          </svg>
        </span>
        <div>
          <p className="hitl-title">Input Required</p>
          <p className="hitl-subtitle">The workflow needs your input to continue</p>
        </div>
        {resolved && (
          <span className="hitl-resolved-badge">
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none">
              <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            Submitted
          </span>
        )}
      </div>

      {/* Divider */}
      <div className="hitl-divider" />

      {/* Fields */}
      <div className="hitl-fields">
        {fields.map(renderField)}
      </div>

      {/* Submit */}
      {!resolved && (
        <button
          className="hitl-submit"
          disabled={!isValid || submitting}
          onClick={handleSubmit}
        >
          {submitting ? (
            <>
              <span className="submit-spinner" />
              Resuming…
            </>
          ) : (
            <>
              Continue
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none">
                <path d="M5 12h14M12 5l7 7-7 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </>
          )}
        </button>
      )}
    </div>
  );
}
