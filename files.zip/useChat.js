import { useState, useCallback, useRef } from 'react';
import { createThread, sendMessage, resumeGraph } from '../utils/api.js';

/**
 * Message shape:
 * {
 *   id:        string,
 *   role:      'user' | 'assistant' | 'hitl' | 'system',
 *   content:   string,           // for user / assistant / system
 *   fields:    FieldDef[],       // for hitl
 *   status:    'pending' | 'done' | 'error',
 * }
 *
 * FieldDef shape (from backend):
 * { name, label, type, required, placeholder }
 */

let _id = 0;
const uid = () => `msg-${Date.now()}-${_id++}`;

export function useChat() {
  const [messages,  setMessages]  = useState([]);
  const [threadId,  setThreadId]  = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error,     setError]     = useState(null);

  // Track current HITL message id so we can mark it resolved
  const hitlMsgIdRef = useRef(null);

  // ── helpers ─────────────────────────────────────────────────
  const addMessage = useCallback((msg) => {
    setMessages(prev => [...prev, { id: uid(), ...msg }]);
  }, []);

  const updateLastAssistant = useCallback((patch) => {
    setMessages(prev => {
      const next = [...prev];
      for (let i = next.length - 1; i >= 0; i--) {
        if (next[i].role === 'assistant' && next[i].status === 'pending') {
          next[i] = { ...next[i], ...patch };
          break;
        }
      }
      return next;
    });
  }, []);

  const resolveHITL = useCallback((id) => {
    setMessages(prev =>
      prev.map(m => m.id === id ? { ...m, resolved: true } : m)
    );
  }, []);

  // ── handle backend response ──────────────────────────────────
  const handleResponse = useCallback((response, pendingAiId) => {
    if (response.type === 'ai') {
      setMessages(prev =>
        prev.map(m =>
          m.id === pendingAiId
            ? { ...m, content: response.content, status: 'done' }
            : m
        )
      );
      hitlMsgIdRef.current = null;
    } else if (response.type === 'hitl') {
      // Remove the pending assistant placeholder
      setMessages(prev => prev.filter(m => m.id !== pendingAiId));

      // Add HITL card
      const hitlId = uid();
      hitlMsgIdRef.current = hitlId;
      setMessages(prev => [
        ...prev,
        {
          id:     hitlId,
          role:   'hitl',
          fields: response.fields,
          status: 'done',
        },
      ]);
    }
  }, []);

  // ── start new chat ───────────────────────────────────────────
  const startNewChat = useCallback(async () => {
    setMessages([]);
    setThreadId(null);
    setError(null);
    hitlMsgIdRef.current = null;
  }, []);

  // ── send a user message ──────────────────────────────────────
  const send = useCallback(async (text) => {
    if (!text.trim() || isLoading) return;

    setError(null);
    setIsLoading(true);

    // Ensure we have a thread
    let tid = threadId;
    if (!tid) {
      try {
        tid = await createThread();
        setThreadId(tid);
      } catch (err) {
        setError('Failed to start a new session. Is the backend running?');
        setIsLoading(false);
        return;
      }
    }

    // Add user message
    addMessage({ role: 'user', content: text, status: 'done' });

    // Add pending assistant placeholder
    const pendingId = uid();
    setMessages(prev => [
      ...prev,
      { id: pendingId, role: 'assistant', content: '', status: 'pending' },
    ]);

    try {
      const response = await sendMessage(tid, text);
      handleResponse(response, pendingId);
    } catch (err) {
      setMessages(prev =>
        prev.map(m =>
          m.id === pendingId
            ? { ...m, content: 'Something went wrong. Please try again.', status: 'error' }
            : m
        )
      );
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  }, [threadId, isLoading, addMessage, handleResponse]);

  // ── submit HITL fields ───────────────────────────────────────
  const submitHITL = useCallback(async (fieldValues) => {
    if (!threadId || isLoading) return;

    const currentHitlId = hitlMsgIdRef.current;

    setError(null);
    setIsLoading(true);

    // Mark HITL as resolved
    if (currentHitlId) resolveHITL(currentHitlId);

    // Show submitted values as a compact system message
    const summary = Object.entries(fieldValues)
      .map(([k, v]) => `${k}: ${v}`)
      .join(' · ');
    addMessage({ role: 'system', content: `Submitted: ${summary}`, status: 'done' });

    // Add pending assistant placeholder
    const pendingId = uid();
    setMessages(prev => [
      ...prev,
      { id: pendingId, role: 'assistant', content: '', status: 'pending' },
    ]);

    try {
      const response = await resumeGraph(threadId, fieldValues);
      handleResponse(response, pendingId);
    } catch (err) {
      setMessages(prev =>
        prev.map(m =>
          m.id === pendingId
            ? { ...m, content: 'Resume failed. Please try again.', status: 'error' }
            : m
        )
      );
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  }, [threadId, isLoading, resolveHITL, addMessage, handleResponse]);

  return {
    messages,
    threadId,
    isLoading,
    error,
    send,
    submitHITL,
    startNewChat,
  };
}
