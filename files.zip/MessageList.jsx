import React, { useEffect, useRef } from 'react';
import Message from './Message.jsx';
import './MessageList.css';

function EmptyState() {
  return (
    <div className="empty-state">
      <div className="empty-icon">
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none">
          <path d="M12 2L2 7l10 5 10-5-10-5z" stroke="currentColor" strokeWidth="1.3" strokeLinejoin="round"/>
          <path d="M2 17l10 5 10-5" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/>
          <path d="M2 12l10 5 10-5" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      </div>
      <h2 className="empty-title">How can I help you?</h2>
      <p className="empty-body">
        Ask anything. If the workflow needs more input, you'll be prompted inline.
      </p>
      <div className="empty-hints">
        <span className="hint-chip">Summarize a document</span>
        <span className="hint-chip">Analyze data</span>
        <span className="hint-chip">Build a workflow</span>
      </div>
    </div>
  );
}

export default function MessageList({ messages, onHITLSubmit }) {
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return (
    <div className="message-list">
      <div className="message-list-inner">
        {messages.length === 0 ? (
          <EmptyState />
        ) : (
          messages.map(msg => (
            <Message
              key={msg.id}
              message={msg}
              onHITLSubmit={onHITLSubmit}
            />
          ))
        )}
        <div ref={bottomRef} />
      </div>
    </div>
  );
}
