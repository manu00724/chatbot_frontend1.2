/**
 * mock-server.js
 *
 * A lightweight Express mock of the LangGraph backend.
 * Run with: node mock-server.js
 *
 * Simulates:
 *   - /thread/new  → returns a fresh thread_id
 *   - /chat        → returns an AI message OR triggers a HITL interrupt
 *   - /resume      → resumes graph after HITL fields submitted
 *
 * Install deps: npm install express cors uuid
 */

import express from 'express';
import cors    from 'cors';
import { v4 as uuidv4 } from 'uuid';

const app  = express();
const PORT = 8000;

app.use(cors());
app.use(express.json());

// In-memory: track which threads are mid-HITL
const threadState = {};

/* ── POST /thread/new ──────────────────── */
app.post('/thread/new', (_req, res) => {
  const thread_id = uuidv4();
  threadState[thread_id] = { turn: 0 };
  console.log(`[NEW THREAD] ${thread_id}`);
  res.json({ thread_id });
});

/* ── POST /chat ────────────────────────── */
app.post('/chat', (req, res) => {
  const { thread_id, message } = req.body;

  if (!thread_id || !threadState[thread_id]) {
    return res.status(400).json({ error: 'Unknown thread_id' });
  }

  const state = threadState[thread_id];
  state.turn++;

  // Every 2nd turn: simulate a HITL interrupt
  if (state.turn % 2 === 0) {
    console.log(`[HITL] thread=${thread_id} turn=${state.turn}`);
    return res.json({
      type:      'hitl',
      thread_id,
      fields: [
        {
          name:        'confirmation',
          label:       'Please confirm the action',
          type:        'select',
          required:    true,
          placeholder: '',
          options: [
            { label: 'Approve',  value: 'approve'  },
            { label: 'Reject',   value: 'reject'   },
            { label: 'Defer',    value: 'defer'    },
          ],
        },
        {
          name:        'reason',
          label:       'Reason (optional)',
          type:        'textarea',
          required:    false,
          placeholder: 'Add context for the workflow…',
        },
      ],
    });
  }

  // Normal AI response
  console.log(`[AI] thread=${thread_id} message="${message}"`);
  res.json({
    type:      'ai',
    thread_id,
    content:   `You asked: "${message}"\n\nThis is a mock response from the LangGraph backend. In production, your graph's output would appear here. The next message in this thread will trigger a Human-In-The-Loop (HITL) interrupt to demonstrate the workflow.`,
  });
});

/* ── POST /resume ──────────────────────── */
app.post('/resume', (req, res) => {
  const { thread_id, fields } = req.body;

  if (!thread_id || !threadState[thread_id]) {
    return res.status(400).json({ error: 'Unknown thread_id' });
  }

  console.log(`[RESUME] thread=${thread_id}`, fields);

  res.json({
    type:      'ai',
    thread_id,
    content:   `Graph resumed successfully.\n\nReceived your input:\n${Object.entries(fields).map(([k,v]) => `• ${k}: ${v}`).join('\n')}\n\nThe workflow has continued from where it was interrupted.`,
  });
});

app.listen(PORT, () => {
  console.log(`Mock LangGraph backend running at http://localhost:${PORT}`);
});
