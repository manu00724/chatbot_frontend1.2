import React, { useState } from 'react';
import Header      from './components/Header.jsx';
import MessageList from './components/MessageList.jsx';
import ChatInput   from './components/ChatInput.jsx';
import ErrorBanner from './components/ErrorBanner.jsx';
import { useChat } from './hooks/useChat.js';
import './App.css';

export default function App() {
  const {
    messages,
    threadId,
    isLoading,
    error,
    send,
    submitHITL,
    startNewChat,
  } = useChat();

  // Disable the text input if the last visible message is an unresolved HITL
  const hasUnresolvedHITL = messages.some(
    m => m.role === 'hitl' && !m.resolved
  );

  const [localError, setLocalError] = useState(null);
  const displayError = error || localError;

  return (
    <div className="app">
      <Header threadId={threadId} onNewChat={startNewChat} />

      {displayError && (
        <ErrorBanner
          message={displayError}
          onDismiss={() => setLocalError(null)}
        />
      )}

      <MessageList
        messages={messages}
        onHITLSubmit={submitHITL}
      />

      <ChatInput
        onSend={send}
        isLoading={isLoading}
        disabled={hasUnresolvedHITL}
      />
    </div>
  );
}
